$( function() {

	var ui = window.app.ns("ui");

	window.builder = function() {
		return new ui.Button({	label: "Default" });
	}	;

});